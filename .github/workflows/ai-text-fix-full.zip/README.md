# 📱 AI Text Assistant for Android
A floating AI-powered text assistant that transforms selected text using ChatGPT (Hindi + English), without replacing your keyboard.
